<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class OrderItem extends Model {
 protected $fillable=['product_id','product_name','quantity','unit_price','line_total'];
 public function order(){return $this->belongsTo(Order::class);}
}
